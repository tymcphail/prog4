﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{
    internal class Dogs
    {
        private string _dogBreed;
        private string _dogGender;
        private string _dogName;
        private string _dogFur;
        private int _dogAge;
        private double _dogPrice;
        private bool _dogBreedAvailable;


        public Dogs(string dogBreed, string dogGender, int dogAge, string dogFur, string dogName, double dogPrice)
        {
            DogBreed = dogBreed;
            DogGender = dogGender;
            DogName = dogName;
            DogFur = dogFur;
            DogAge = dogAge;
            DogPrice = dogPrice;
            DogBreedAvailable();
        }
        public string DogBreed
        {
            get { return _dogBreed; }
            set { _dogBreed = value; }
        }
        public string DogGender
        {
            get { return _dogGender; }
            set { _dogGender = value; }
        }
        public string DogName
        {
            get { return _dogName; }
            set { _dogName = value; }
        }
        public string DogFur
        {
            get { return _dogFur; }
            set { _dogFur = value; }
        }
        public int DogAge
        {
            get { return _dogAge; }
            set
            {
                if (value > 0)
                    _dogAge = value;
                else
                    _dogAge = 3;
            }
        }
        public double DogPrice
        {
            get { return _dogPrice; }
            set { _dogPrice = value; }
        }

        public void DogAvailable()
        {
            _dogBreedAvailable = true;
        }
        public void DogAdopted()
        {
            _dogBreedAvailable = false;
        }
        public bool DogBreedAvailable()
        {
            return _dogBreedAvailable;
        }
        public override string ToString()
        {
            return $"Name:{DogName}\n" + $"Breed:{DogBreed}\n" + $"Gender:{DogGender}\n" + $"Age:{DogAge}\n" + $"Fur Color:{DogFur}\n" + $"Price:{DogPrice}\n" + $"Is Available:{DogBreedAvailable()}\n";


        }

    }
}
