﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{
    internal class Cats
    {
        private string _catBreed;
        private string _catGender;
        private string _catName;
        private string _catFur;
        private int _catAge;
        private double _catPrice;
        private bool _catBreedAvailable=true;


        public Cats(string catBreed, string catGender, int catAge, string catFur, string catName, double catPrice)
        {
            CatBreed = catBreed;
            CatGender = catGender;
            CatName = catName;
            CatFur = catFur;
            CatAge = catAge;
            CatPrice = catPrice;
            Available();

        }
        public string CatBreed
        {
            get { return _catBreed; }
            set { _catBreed = value; }
        }
        public string CatGender
        {
            get { return _catGender; }
            set { _catGender = value; }
        }
        public string CatName
        {
            get { return _catName; }
            set { _catName = value; }
        }
        public string CatFur
        {
            get { return _catFur; }
            set { _catFur = value; }
        }
        public int CatAge
        {
            get { return _catAge; }
            set
            {
                if (value > 0)
                    _catAge = value;
                else
                    _catAge = 3;
            }
        }
        public double CatPrice
        {
            get { return _catPrice; }
            set { _catPrice = value; }
        }

        public void CatAvailable()
        {
            _catBreedAvailable = true;
        }
        public void CatAdopted()
        {
            _catBreedAvailable = false;
        }
        public bool Available()
        {
            return _catBreedAvailable;
        }
        public override string ToString()
        {
            return $"Name:{CatName}\n" + $"Breed:{CatBreed}\n" + $"Gender:{CatGender}\n" + $"Age:{CatAge}\n" + $"Fur Color:{CatFur}\n" + $"Price:{CatPrice}\n" + $"Is Available:{Available()}\n";


        }
    }
}
