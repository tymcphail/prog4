﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //S2335,program 4 due april 20, section 4232, this program displays animals available for adoption
            Dogs dog1 = new Dogs("Labrador", "F", 13, "Yellow", "Cobalt", 500);
            Dogs dog2 = new Dogs("Schnauzer", "m", 11, "white", "nala", 600);
            Dogs dog3 = new Dogs("Golden Retreiver", "F", 23, "brown", "digger", 70);
            Dogs dog4 = new Dogs("Poodle", "F", 3, "grey", "rufus", 800);
            Dogs dog5 = new Dogs("Yorkie", "m", 1, "black", "Dog", 900);//5 total

            Dogs[] dogs = { dog1, dog2, dog3, dog4, dog5 };

            Cats cat1 = new Cats("Siamese", "m", 1, "yellow-orange", "Lola", 1000);//5 more
            Cats cat2 = new Cats("tabby", "F", 3, "Black", "mike", 1600);//5 more
            Cats cat3 = new Cats("main coon", "m", 7, "grey", "kitty", 100);//5 more
            Cats cat4 = new Cats("mixed", "F", 4, "calico", "mittens", 3500);//5 more
            Cats cat5 = new Cats("barn cat", "m", 5, "white", "bandit", 5000);//5 more

            Cats[] cats = { cat1, cat2, cat3, cat4, cat5 };
            

            Console.WriteLine("list of Pets");
            DisplayCats(cats);
            DisplayDogs(dogs);
            cat1.CatAvailable();
            cat2.CatAvailable();
            cat3.CatAvailable();
            cat4.CatAvailable();
            cat5.CatAvailable();
            dog1.DogAdopted();
            dog2.DogAdopted();
            dog3.DogAdopted();
            dog4.DogAdopted();
            dog5.DogAdopted();

        }
           
            public static void DisplayCats(Cats[] cats)
            {
                foreach (Cats catXYZ in cats)
                {
                    Console.WriteLine(catXYZ);
                    Console.WriteLine();
                }
            }
            public static void DisplayDogs(Dogs[] dogs)
            {
                foreach (Dogs dogXYZ in dogs)
                {
                    Console.WriteLine(dogXYZ);
                    Console.WriteLine();
                }
            }

        }
    }

